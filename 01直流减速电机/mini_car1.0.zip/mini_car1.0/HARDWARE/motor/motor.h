#ifndef __MOTOR_H
#define __MOTOR_H	 
#include "sys.h"

// TIM_SetCompare2(TIM3,100);	// ����ռ�ձ�
#define PWMA1   TIM8->CCR3
#define PWMA2   TIM8->CCR1 
#define PWMB1   TIM8->CCR4  
#define PWMB2   TIM8->CCR2

// ���ʹ�ö�ʱ��8����
void TIM8_PWM_Init(u16 arr,u16 psc); 
void motor_control(u8 number,int speed);
void Set_Pwm(int motor_a,int motor_b);
void Xianfu_Pwm(int amplitude);
int Incremental_PI_Left (int Encoder,int Target);
int Incremental_PI_Right (int Encoder,int Target);
void controlTest(void);

		 				    
#endif
