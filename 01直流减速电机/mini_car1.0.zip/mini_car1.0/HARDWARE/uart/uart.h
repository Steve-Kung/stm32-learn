#ifndef __UART_H
#define __UART_H 
#include "sys.h"


void uart5_send(u8 data);
void uart5_init(u32 bound);
void UART5_IRQHandler(void);
void UART_TX(void);
#endif

